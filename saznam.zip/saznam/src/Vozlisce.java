public class Vozlisce {
    public int kljuc;

    public Vozlisce rep;

    public Vozlisce(int kljuc){
        this.kljuc = kljuc;
    }


    public boolean najdi(int element){
        if(element == kljuc){
            return true;
        }else if(rep == null || kljuc > element){
            return false;
        }else{
            return rep.najdi(element);
        }
    }

    public boolean vstavi(int element){
        if(rep == null){
            Vozlisce novo = new Vozlisce(element);
            rep = novo;

            return  true;
        }else if(element <= rep.kljuc){
            if( element < rep.kljuc ){
                Vozlisce novo = new Vozlisce(element);
                novo.rep = rep;
                rep = novo;
            }
            return true;
        }else{
            return rep.vstavi(element);
        }
    }


    public boolean brisi(int element){
        if(rep == null){
            return false;
        }else if(element == rep.kljuc){//gledamo kljuc naslednjega elementa
            //moramo zbrisati nasljednji elemetn
            rep = rep.rep;
            return true;
        }else {
            return rep.brisi(element);
        }
    }
}
