public class Start {
public static void main(String[] args){
    PovezanSeznam ps = new PovezanSeznam();//USTVARIMO PRAZEN SEZNAM

    int n = 3;

    System.out.println(ps.najdi(n));

    ps.vstavi(5);
    System.out.println(ps.najdi(5));

    ps.brisi(5);
    System.out.println(ps.najdi(5));

}
}
