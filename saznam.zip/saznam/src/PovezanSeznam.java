public class PovezanSeznam { //UREJENI POVEZAN SEZNAM //HRANI REFERENCO NA ZACETEK POVEZANEGA SEZNAMA

    public Vozlisce glava; //prvi element v setnamu
    //A SEZNAM JE PRAZAN, GLAVA JE NULL



    public boolean najdi(int element){
        if (glava == null){
            return  false;
        }else{
            return glava.najdi(element);
        }
    }

    public boolean vstavi(int element){
        if(glava == null){
            Vozlisce novo = new Vozlisce(element);
            glava = novo;
            return true;
        }else if(element <= glava.kljuc){ //pregledamo kljuc nasljednjega elementa
            if(element < glava.kljuc){
                Vozlisce novo = new Vozlisce(element);
                novo.rep = glava;
                glava = novo;
            }
            return  true;
        }else{
            //delegiramo delo vozliscu
            return glava.vstavi(element);
        }
    }

    public boolean brisi(int element){
        if(glava == null){
            return false;
        }else if(element == glava.kljuc){//pregledam kljuc glava
            glava = glava.rep;
            return true;
        }else{
            return glava.brisi(element);
        }
    }
}
